<!DOCTYPE html>
<!--
modele.php
c:/xampp/htdocs/MonProjetPerso/views/modele.php
http://localhost/MonProjetPerso/views/modele.php
-->
<html>

<head>
    <meta charset="UTF-8">
    <title></title>
    <link rel="stylesheet" href="../css/style.css" />
</head>

<body>
    <header>
        <?php
        include './partials/header.php';
        ?>
    </header>

    <hr/>

    <nav>
        <?php
        include './partials/nav.php';
        ?>
    </nav>

    <hr/>

    <section>
        SECTION
        <?php
        
        ?>
    </section>

    <hr/>

    <footer>
        <?php
        include './partials/footer.php';
        ?>
    </footer>
</body>

</html>