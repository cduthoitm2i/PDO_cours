<?php

?>

<ul>
    <li><a href="../views/Accueil.php">Accueil</a></li>
    <li><a href="../views/Catalogue.php">Catalogue</a></li>
    <li><a href="../views/Inscription.php">Inscription</a></li>
    <li><a href="../views/Authentification.php">Authentification</a></li>
</ul>